using Bikxie.Properties;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Bikxie
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void signup_Click(object sender, EventArgs e)
        {
            string option = mode.Text;

            try
            {
                if (option == "")
                {
                    throw new InvaildModeException();
                }
                else if (option == "Driver")
                {
                    driverRegisteration dg = new driverRegisteration();
                    dg.Show();
                }
                else if (option == "Passenger")
                {
                    passengerRegistration pg = new passengerRegistration();
                    pg.Show();
                }
                else
                {
                    throw new InvaildSelectOptionException();
                }
            }
            catch (InvaildSelectOptionException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (InvaildModeException ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        private void showpass_CheckedChanged(object sender, EventArgs e)
        {
            if (!showpass.Checked)
            {
                password.UseSystemPasswordChar = true;
            }
            else
            {
                password.UseSystemPasswordChar = false;
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            mode.Text = "";

        }

        private void signin_Click(object sender, EventArgs e)
        {
           
            SignIn();

        }
        public void SignIn()
        {
            try
            {
                if ( mode.Text == "" || uname.Text == "" || password.Text == "")
                {
                    throw new InvaildModeException();
                    return;
                }

                string selectedMode = mode.Text.Trim();
                string username = uname.Text.Trim();
                string pass = password.Text.Trim();

                if (selectedMode == "Admin")
                {
                    
                    string adminUsername = "admin";
                    string adminPassword = "12345";

                    if (username == adminUsername && pass == adminPassword)
                    {
                        MessageBox.Show("Successfully logged in as Admin.");

                        Admin admin = new Admin();
                        admin.Show();
                    }
                    else
                    {
                        throw new InvaildCheckException();
                    }
                }
                else if (selectedMode == "Driver")
                {
                    
                        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");
                    
                        con.Open();

                        string query = $"SELECT * FROM driver WHERE DriverUname = @Username AND DriverPassword = @Password AND IsActive = 1";

                        SqlCommand cmd = new SqlCommand(query, con);
                        
                        cmd.Parameters.AddWithValue("@Username", username);

                        cmd.Parameters.AddWithValue("@Password", pass);

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);

                        DataTable dt = new DataTable();

                        sda.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            MessageBox.Show($"Successfully logged in as Driver.");

                            UserSession.DriverUsername= username;

                            Driver_main dm = new Driver_main();

                            dm.Show();
                        }
                        else
                        {
                                string q = $"SELECT * FROM driver WHERE DriverUname = @Username AND IsActive = 0";

                                SqlCommand cmd1 = new SqlCommand(q, con);

                                cmd1.Parameters.AddWithValue("@Username", username);

                                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);

                                DataTable dt1 = new DataTable();

                                sda1.Fill(dt1);

                                if (dt1.Rows.Count > 0)
                                {
                                    MessageBox.Show("Your ID has been banned, contact admin.");
                                }
                                else
                                {
                                    throw new InvaildCheckException();
                                }  
                        }
                }
                else if (selectedMode == "Passenger")
                {

                    SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");
                   
                    con.Open();

                    string query = $"SELECT * FROM passenger WHERE PassengerUname = @Username AND PassengerPassword = @Password";

                    SqlCommand cmd = new SqlCommand(query, con);
                       
                    cmd.Parameters.AddWithValue("@Username", username);

                    cmd.Parameters.AddWithValue("@Password", pass);

                    SqlDataAdapter sda = new SqlDataAdapter(cmd);

                    DataTable dt = new DataTable();

                    sda.Fill(dt);
                           
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show($"Successfully logged in as Passenger.");

                        UserSession.PassengerUsername = username;

                        passengerBook pb=new passengerBook();
                        pb.Show();
                    }
                    else
                    {
                        throw new InvaildCheckException();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid mode selected. Please select 'Admin', 'Driver', or 'Passenger'.");
                }
            }
            
            catch(InvaildCheckException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch(InvaildModeException ex2)
            {
                MessageBox.Show(ex2.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

    }

    internal class InvaildSelectOptionException : Exception
    {
        public override string Message
        {
            get
            {
                return (" Already Admin have an Account.Please Directly SignIn");
            }
        }
    }
    internal class InvaildCheckException : Exception
    {
        public override string Message
        {
            get
            {
                return ("Check username and password !!");
            }
        }
    }
    internal class InvaildModeException : Exception
    {
        public override string Message
        {
            get
            {
                return ("All fields are mandatory. Please fill in the required fields !!!");
            }
        }
    }

    public static class UserSession
    {
        public static string BillStatus = "paid";
        public static string PassengerUsername { get; set; }
        public static string DriverUsername { get; set; }
        public static string Billamount {  get; set; }
        public static string Kilometers { get; set; }
        public static string Pickup { get; set; }
        public static string Drop { get; set; }

        public static string Passengerid { get; set; }

        public static string Driverid { get; set; }

        public static string otp { get; set; }

        public static string Starttime { get; set; }

        public static string Endtime { get; set; }

        public static string Date { get; set; }



    }
    
}
