﻿namespace Bikxie.Properties
{
    partial class passengerBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(passengerBook));
            label4 = new Label();
            label3 = new Label();
            logout = new Button();
            myrides = new Button();
            bookride = new Button();
            panel1 = new Panel();
            mainpanel = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.MidnightBlue;
            label4.Font = new Font("Times New Roman", 30F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(81, 39);
            label4.Name = "label4";
            label4.Size = new Size(160, 57);
            label4.TabIndex = 18;
            label4.Text = "Bikxie";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.MidnightBlue;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(3, 96);
            label3.Name = "label3";
            label3.Size = new Size(310, 22);
            label3.TabIndex = 17;
            label3.Text = "______________________________";
            // 
            // logout
            // 
            logout.BackColor = Color.MidnightBlue;
            logout.BackgroundImageLayout = ImageLayout.None;
            logout.FlatAppearance.BorderColor = Color.MidnightBlue;
            logout.FlatAppearance.BorderSize = 0;
            logout.FlatAppearance.MouseDownBackColor = Color.Black;
            logout.FlatStyle = FlatStyle.Flat;
            logout.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            logout.ForeColor = Color.White;
            logout.Image = Resources.Aha_Soft_Free_3d_Glossy_Interface_Run_64;
            logout.ImageAlign = ContentAlignment.MiddleLeft;
            logout.Location = new Point(78, 860);
            logout.Name = "logout";
            logout.Size = new Size(202, 70);
            logout.TabIndex = 16;
            logout.Text = "Log Out";
            logout.TextAlign = ContentAlignment.MiddleRight;
            logout.UseVisualStyleBackColor = false;
            logout.Click += logout_Click;
            // 
            // myrides
            // 
            myrides.BackColor = Color.MidnightBlue;
            myrides.BackgroundImageLayout = ImageLayout.None;
            myrides.FlatAppearance.BorderColor = Color.MidnightBlue;
            myrides.FlatAppearance.BorderSize = 0;
            myrides.FlatAppearance.MouseDownBackColor = Color.Black;
            myrides.FlatStyle = FlatStyle.Flat;
            myrides.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            myrides.ForeColor = Color.White;
            myrides.Image = Resources.Icojam_Blue_Bits_Database_check_64;
            myrides.ImageAlign = ContentAlignment.MiddleLeft;
            myrides.Location = new Point(54, 540);
            myrides.Name = "myrides";
            myrides.Size = new Size(226, 65);
            myrides.TabIndex = 15;
            myrides.Text = "My Rides";
            myrides.TextAlign = ContentAlignment.MiddleRight;
            myrides.UseVisualStyleBackColor = false;
            myrides.Click += myrides_Click;
            // 
            // bookride
            // 
            bookride.BackColor = Color.MidnightBlue;
            bookride.BackgroundImageLayout = ImageLayout.None;
            bookride.FlatAppearance.BorderColor = Color.MidnightBlue;
            bookride.FlatAppearance.BorderSize = 0;
            bookride.FlatAppearance.MouseDownBackColor = Color.Black;
            bookride.FlatStyle = FlatStyle.Flat;
            bookride.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            bookride.ForeColor = Color.White;
            bookride.Image = Resources.Bike_Taxi_App_Bike_Taxi_Kolkata_Bike_Taxi_Number_Bike_Taxi_BroomBoom_1__1_;
            bookride.ImageAlign = ContentAlignment.MiddleLeft;
            bookride.Location = new Point(54, 372);
            bookride.Name = "bookride";
            bookride.Size = new Size(232, 62);
            bookride.TabIndex = 14;
            bookride.Text = "Book Ride";
            bookride.TextAlign = ContentAlignment.MiddleRight;
            bookride.UseVisualStyleBackColor = false;
            bookride.Click += bookride_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.MidnightBlue;
            panel1.Controls.Add(label4);
            panel1.Controls.Add(myrides);
            panel1.Controls.Add(logout);
            panel1.Controls.Add(bookride);
            panel1.Controls.Add(label3);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(334, 1031);
            panel1.TabIndex = 19;
            // 
            // mainpanel
            // 
            mainpanel.Location = new Point(334, 0);
            mainpanel.Name = "mainpanel";
            mainpanel.Size = new Size(1002, 1031);
            mainpanel.TabIndex = 20;
            // 
            // passengerBook
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1336, 1031);
            Controls.Add(mainpanel);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "passengerBook";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "passengerBook";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Button Rides;
        private Label label4;
        private Label label3;
        private Button logout;
        private Button myrides;
        private Button bookride;
        private Button Ban;
        private Panel panel1;
        private Panel mainpanel;
    }
}