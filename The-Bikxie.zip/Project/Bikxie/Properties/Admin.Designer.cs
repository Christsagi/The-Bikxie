﻿namespace Bikxie.Properties
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            splitter1 = new Splitter();
            Ban = new Button();
            DriverDB = new Button();
            PassengerDB = new Button();
            Back = new Button();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            button1 = new Button();
            banid = new TextBox();
            label2 = new Label();
            label4 = new Label();
            label3 = new Label();
            Rides = new Button();
            refresh = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // splitter1
            // 
            splitter1.BackColor = Color.MidnightBlue;
            splitter1.Location = new Point(0, 0);
            splitter1.Name = "splitter1";
            splitter1.Size = new Size(338, 1031);
            splitter1.TabIndex = 0;
            splitter1.TabStop = false;
            // 
            // Ban
            // 
            Ban.BackColor = Color.MidnightBlue;
            Ban.BackgroundImageLayout = ImageLayout.None;
            Ban.FlatAppearance.BorderColor = Color.MidnightBlue;
            Ban.FlatAppearance.BorderSize = 0;
            Ban.FlatAppearance.MouseDownBackColor = Color.Black;
            Ban.FlatStyle = FlatStyle.Flat;
            Ban.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Ban.ForeColor = Color.White;
            Ban.Image = (Image)resources.GetObject("Ban.Image");
            Ban.ImageAlign = ContentAlignment.MiddleLeft;
            Ban.Location = new Point(45, 493);
            Ban.Name = "Ban";
            Ban.Size = new Size(248, 58);
            Ban.TabIndex = 1;
            Ban.Text = "Ban Driver";
            Ban.TextAlign = ContentAlignment.MiddleRight;
            Ban.UseVisualStyleBackColor = false;
            Ban.Click += Ban_Click;
            // 
            // DriverDB
            // 
            DriverDB.BackColor = Color.MidnightBlue;
            DriverDB.BackgroundImageLayout = ImageLayout.None;
            DriverDB.FlatAppearance.BorderColor = Color.MidnightBlue;
            DriverDB.FlatAppearance.BorderSize = 0;
            DriverDB.FlatAppearance.MouseDownBackColor = Color.Black;
            DriverDB.FlatStyle = FlatStyle.Flat;
            DriverDB.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            DriverDB.ForeColor = Color.White;
            DriverDB.Image = Resources.Icojam_Blue_Bits_Database_check_64;
            DriverDB.ImageAlign = ContentAlignment.MiddleLeft;
            DriverDB.Location = new Point(45, 320);
            DriverDB.Name = "DriverDB";
            DriverDB.Size = new Size(209, 79);
            DriverDB.TabIndex = 2;
            DriverDB.Text = "Drivers";
            DriverDB.TextAlign = ContentAlignment.MiddleRight;
            DriverDB.UseVisualStyleBackColor = false;
            DriverDB.Click += DriverDB_Click;
            // 
            // PassengerDB
            // 
            PassengerDB.BackColor = Color.MidnightBlue;
            PassengerDB.BackgroundImageLayout = ImageLayout.None;
            PassengerDB.FlatAppearance.BorderColor = Color.MidnightBlue;
            PassengerDB.FlatAppearance.BorderSize = 0;
            PassengerDB.FlatAppearance.MouseDownBackColor = Color.Black;
            PassengerDB.FlatStyle = FlatStyle.Flat;
            PassengerDB.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            PassengerDB.ForeColor = Color.White;
            PassengerDB.Image = Resources.Icojam_Blue_Bits_Database_check_64;
            PassengerDB.ImageAlign = ContentAlignment.MiddleLeft;
            PassengerDB.Location = new Point(45, 405);
            PassengerDB.Name = "PassengerDB";
            PassengerDB.Size = new Size(248, 72);
            PassengerDB.TabIndex = 3;
            PassengerDB.Text = "Passengers\r\n";
            PassengerDB.TextAlign = ContentAlignment.MiddleRight;
            PassengerDB.UseVisualStyleBackColor = false;
            PassengerDB.Click += PassengerDB_Click;
            // 
            // Back
            // 
            Back.BackColor = Color.MidnightBlue;
            Back.BackgroundImageLayout = ImageLayout.None;
            Back.FlatAppearance.BorderColor = Color.MidnightBlue;
            Back.FlatAppearance.BorderSize = 0;
            Back.FlatAppearance.MouseDownBackColor = Color.Black;
            Back.FlatStyle = FlatStyle.Flat;
            Back.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Back.ForeColor = Color.White;
            Back.Image = Resources.Aha_Soft_Free_3d_Glossy_Interface_Run_64;
            Back.ImageAlign = ContentAlignment.MiddleLeft;
            Back.Location = new Point(71, 855);
            Back.Name = "Back";
            Back.Size = new Size(202, 86);
            Back.TabIndex = 4;
            Back.Text = "Log Out";
            Back.TextAlign = ContentAlignment.MiddleRight;
            Back.UseVisualStyleBackColor = false;
            Back.Click += Back_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonShadow;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = Color.Gray;
            dataGridView1.Location = new Point(368, 169);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(956, 382);
            dataGridView1.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(670, 714);
            label1.Name = "label1";
            label1.Size = new Size(325, 22);
            label1.TabIndex = 6;
            label1.Text = "Enter  the id of the Driver you want Ban";
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonShadow;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(630, 910);
            button1.Name = "button1";
            button1.Size = new Size(155, 50);
            button1.TabIndex = 7;
            button1.Text = "Ban";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // banid
            // 
            banid.BackColor = Color.DarkGray;
            banid.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            banid.ForeColor = Color.White;
            banid.Location = new Point(685, 818);
            banid.Name = "banid";
            banid.Size = new Size(285, 34);
            banid.TabIndex = 8;
            banid.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(590, 757);
            label2.Name = "label2";
            label2.Size = new Size(470, 22);
            label2.TabIndex = 9;
            label2.Text = "______________________________________________";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.MidnightBlue;
            label4.Font = new Font("Times New Roman", 30F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(71, 27);
            label4.Name = "label4";
            label4.Size = new Size(160, 57);
            label4.TabIndex = 11;
            label4.Text = "Bikxie";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.MidnightBlue;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(11, 71);
            label3.Name = "label3";
            label3.Size = new Size(310, 22);
            label3.TabIndex = 10;
            label3.Text = "______________________________";
            // 
            // Rides
            // 
            Rides.BackColor = Color.MidnightBlue;
            Rides.BackgroundImageLayout = ImageLayout.None;
            Rides.FlatAppearance.BorderColor = Color.MidnightBlue;
            Rides.FlatAppearance.BorderSize = 0;
            Rides.FlatAppearance.MouseDownBackColor = Color.Black;
            Rides.FlatStyle = FlatStyle.Flat;
            Rides.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            Rides.ForeColor = Color.White;
            Rides.Image = Resources.Icojam_Blue_Bits_Database_check_64;
            Rides.ImageAlign = ContentAlignment.MiddleLeft;
            Rides.Location = new Point(45, 591);
            Rides.Name = "Rides";
            Rides.Size = new Size(276, 76);
            Rides.TabIndex = 12;
            Rides.Text = "Rides History";
            Rides.TextAlign = ContentAlignment.MiddleRight;
            Rides.UseVisualStyleBackColor = false;
            Rides.Click += Rides_Click;
            // 
            // refresh
            // 
            refresh.BackColor = SystemColors.ButtonShadow;
            refresh.FlatStyle = FlatStyle.Flat;
            refresh.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            refresh.Location = new Point(862, 910);
            refresh.Name = "refresh";
            refresh.Size = new Size(155, 50);
            refresh.TabIndex = 13;
            refresh.Text = "Refresh";
            refresh.UseVisualStyleBackColor = false;
            refresh.Click += refresh_Click;
            // 
            // Admin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonShadow;
            ClientSize = new Size(1336, 1031);
            Controls.Add(refresh);
            Controls.Add(Rides);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(banid);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(Back);
            Controls.Add(PassengerDB);
            Controls.Add(DriverDB);
            Controls.Add(Ban);
            Controls.Add(splitter1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Admin";
            Text = "Admin";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Splitter splitter1;
        private Button Ban;
        private Button DriverDB;
        private Button PassengerDB;
        private Button Back;
        private DataGridView dataGridView1;
        private Label label1;
        private Button button1;
        private TextBox banid;
        private Label label2;
        private Label label4;
        private Label label3;
        private Button Rides;
        private Button refresh;
    }
}