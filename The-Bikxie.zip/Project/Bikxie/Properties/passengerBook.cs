﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bikxie.Properties
{
    public partial class passengerBook : Form
    {
        public passengerBook()
        {
            InitializeComponent();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void myrides_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

                string q = "select * from Ridehistory where PassengerName=@PassengerName";

                SqlCommand cmd = new SqlCommand(q, con);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                cmd.Parameters.AddWithValue("@PassengerName", UserSession.PassengerUsername);

                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    myride rideForm = new myride();

                    rideForm.dataGridView1.DataSource = dt;

                    Navigate.LoadForm(this.mainpanel, rideForm);

                }
                else
                {
                    MessageBox.Show("No data available.");
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Exception occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                MessageBox.Show("Data's Show Successfully");
            }
        }

        private void bookride_Click(object sender, EventArgs e)
        {
            Navigate.LoadForm(this.mainpanel, new BookRIde());
        }
    }
}
