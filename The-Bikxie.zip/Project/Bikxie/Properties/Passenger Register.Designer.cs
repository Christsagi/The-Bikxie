﻿namespace Bikxie.Properties
{
    partial class passengerRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(passengerRegistration));
            label3 = new Label();
            pback = new Button();
            pregister = new Button();
            ppassword = new TextBox();
            label11 = new Label();
            puname = new TextBox();
            label10 = new Label();
            pmob = new TextBox();
            label7 = new Label();
            pfemale = new RadioButton();
            pmale = new RadioButton();
            label6 = new Label();
            page = new TextBox();
            label5 = new Label();
            pname = new TextBox();
            label4 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 16.2F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(704, 9);
            label3.Name = "label3";
            label3.Size = new Size(114, 38);
            label3.TabIndex = 4;
            label3.Text = "Sign Up";
            // 
            // pback
            // 
            pback.BackColor = Color.LightSteelBlue;
            pback.FlatAppearance.BorderSize = 2;
            pback.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            pback.Image = Resources.Custom_Icon_Design_Flatastic_1_Back_48;
            pback.ImageAlign = ContentAlignment.MiddleLeft;
            pback.Location = new Point(71, 837);
            pback.Name = "pback";
            pback.Size = new Size(146, 55);
            pback.TabIndex = 40;
            pback.Text = "Back";
            pback.TextAlign = ContentAlignment.MiddleRight;
            pback.UseVisualStyleBackColor = false;
            pback.Click += pback_Click;
            // 
            // pregister
            // 
            pregister.BackColor = Color.LightSteelBlue;
            pregister.FlatAppearance.BorderSize = 2;
            pregister.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            pregister.ForeColor = Color.Black;
            pregister.Image = Resources.Graphicloads_Folded_Check_contact_folded_48;
            pregister.ImageAlign = ContentAlignment.MiddleLeft;
            pregister.Location = new Point(1016, 837);
            pregister.Name = "pregister";
            pregister.Size = new Size(181, 55);
            pregister.TabIndex = 39;
            pregister.Text = "Register";
            pregister.TextAlign = ContentAlignment.MiddleRight;
            pregister.UseVisualStyleBackColor = false;
            pregister.Click += pregister_Click;
            // 
            // ppassword
            // 
            ppassword.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ppassword.Location = new Point(898, 611);
            ppassword.Name = "ppassword";
            ppassword.Size = new Size(363, 30);
            ppassword.TabIndex = 38;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.White;
            label11.Location = new Point(724, 608);
            label11.Name = "label11";
            label11.Size = new Size(136, 33);
            label11.TabIndex = 37;
            label11.Text = "Password :";
            // 
            // puname
            // 
            puname.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            puname.Location = new Point(898, 484);
            puname.Name = "puname";
            puname.Size = new Size(363, 30);
            puname.TabIndex = 36;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(724, 484);
            label10.Name = "label10";
            label10.Size = new Size(152, 33);
            label10.TabIndex = 35;
            label10.Text = "User Name :";
            // 
            // pmob
            // 
            pmob.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            pmob.Location = new Point(898, 377);
            pmob.Name = "pmob";
            pmob.Size = new Size(363, 30);
            pmob.TabIndex = 34;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(724, 373);
            label7.Name = "label7";
            label7.Size = new Size(124, 33);
            label7.TabIndex = 33;
            label7.Text = "Mob.No :";
            // 
            // pfemale
            // 
            pfemale.AutoSize = true;
            pfemale.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            pfemale.ForeColor = Color.White;
            pfemale.Location = new Point(1097, 277);
            pfemale.Name = "pfemale";
            pfemale.Size = new Size(100, 30);
            pfemale.TabIndex = 32;
            pfemale.TabStop = true;
            pfemale.Text = "Female";
            pfemale.UseVisualStyleBackColor = true;
            // 
            // pmale
            // 
            pmale.AutoSize = true;
            pmale.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            pmale.ForeColor = Color.White;
            pmale.Location = new Point(898, 280);
            pmale.Name = "pmale";
            pmale.Size = new Size(78, 30);
            pmale.TabIndex = 31;
            pmale.TabStop = true;
            pmale.Text = "Male";
            pmale.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(724, 274);
            label6.Name = "label6";
            label6.Size = new Size(110, 33);
            label6.TabIndex = 30;
            label6.Text = "Gender :";
            // 
            // page
            // 
            page.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            page.Location = new Point(898, 184);
            page.Name = "page";
            page.Size = new Size(363, 30);
            page.TabIndex = 29;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(724, 180);
            label5.Name = "label5";
            label5.Size = new Size(74, 33);
            label5.TabIndex = 28;
            label5.Text = "Age :";
            // 
            // pname
            // 
            pname.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            pname.Location = new Point(898, 98);
            pname.Name = "pname";
            pname.Size = new Size(363, 30);
            pname.TabIndex = 27;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(724, 94);
            label4.Name = "label4";
            label4.Size = new Size(94, 33);
            label4.TabIndex = 26;
            label4.Text = "Name :";
            label4.Click += label4_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.BorderStyle = BorderStyle.Fixed3D;
            pictureBox1.Location = new Point(56, 267);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(316, 349);
            pictureBox1.TabIndex = 25;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Book Antiqua", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(56, 122);
            label2.Name = "label2";
            label2.Size = new Size(280, 28);
            label2.TabIndex = 24;
            label2.Text = "Vehicles at your footsteps";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 25.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(40, 62);
            label1.Name = "label1";
            label1.Size = new Size(244, 51);
            label1.TabIndex = 23;
            label1.Text = "The Bikxie";
            // 
            // passengerRegistration
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(1336, 1031);
            Controls.Add(pback);
            Controls.Add(pregister);
            Controls.Add(ppassword);
            Controls.Add(label11);
            Controls.Add(puname);
            Controls.Add(label10);
            Controls.Add(pmob);
            Controls.Add(label7);
            Controls.Add(pfemale);
            Controls.Add(pmale);
            Controls.Add(label6);
            Controls.Add(page);
            Controls.Add(label5);
            Controls.Add(pname);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(label3);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "passengerRegistration";
            Text = "Passenger Registeration";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Button pback;
        private Button pregister;
        private TextBox ppassword;
        private Label label11;
        private TextBox puname;
        private Label label10;
        private TextBox pmob;
        private Label label7;
        private RadioButton pfemale;
        private RadioButton pmale;
        private Label label6;
        private TextBox page;
        private Label label5;
        private TextBox pname;
        private Label label4;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label1;
    }
}