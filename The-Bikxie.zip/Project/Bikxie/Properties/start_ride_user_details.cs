﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace Bikxie.Properties
{
    public partial class start_ride_user_details : Form
    {
        public start_ride_user_details()
        {
            InitializeComponent();
        }

        private void rideaccept_Click(object sender, EventArgs e)
        {
            UserSession.Passengerid = pid.Text;

            this.Close();

            Driver_update driver_Update = new Driver_update();

            driver_Update.Show();
        }

        Login login = new Login();

        private void available_CheckedChanged(object sender, EventArgs e)
        {

            string status = "Available";

            Status(status);

        }

        private void notavailable_CheckedChanged(object sender, EventArgs e)
        {
            string status = "Not Available";

            Status(status);
        }

        private void riding_CheckedChanged(object sender, EventArgs e)
        {
            string status = "Riding";

            Status(status);
        }

        public void Status(string status)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

            try
            {
                con.Open();


                string q = "UPDATE driver SET Status = @Status WHERE DriverUname = @DriverUname";

                SqlCommand cmd = new SqlCommand(q, con);

                cmd.Parameters.AddWithValue("@Status", status);

                cmd.Parameters.AddWithValue("@DriverUname", UserSession.DriverUsername);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
