﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bikxie.Properties
{
    public partial class Driver_main : Form
    {
        public Driver_main()
        {
            InitializeComponent();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkride_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

                string q = "select * from Ridehistory where DriverName=@DriverName";

                SqlCommand cmd = new SqlCommand(q, con);
                
                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                cmd.Parameters.AddWithValue("@DriverName", UserSession.DriverUsername);

                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    myride rideForm = new myride();

                    rideForm.dataGridView1.DataSource = dt;

                    Navigate.LoadForm(this.mainpanel, rideForm);

                }
                else
                {
                    MessageBox.Show("No data available.");
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Exception occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                MessageBox.Show("Data's Show Successfully");
            }
            
        }

        private void startdriving_Click(object sender, EventArgs e)
        {
            Navigate.LoadForm(this.mainpanel, new start_ride_user_details());
        }
    }
}
