﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bikxie.Properties
{
    public partial class Ride_Details : Form
    {
        public Ride_Details()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Paid_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Rides has Completed Succesfully..");
            this.Close();
            start_ride_user_details st = new start_ride_user_details();
            st.Close();
            BookRIde br = new BookRIde();
            br.Close();
            passengerBook pb = new passengerBook();
            pb.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {




            try
            {

                if (did.Text == "")
                {
                    MessageBox.Show("Please Enter Pick up & Drop location");
                    return;
                }
                UserSession.Driverid = did.Text;



                this.Hide();

                start_ride_user_details sr = new start_ride_user_details();


                SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

                string q = "select PassengerId,PassengerName,PassengerMobileNo from passenger where PassengerUname = @PassengerUname ";

                SqlCommand cmd = new SqlCommand(q, con);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                cmd.Parameters.AddWithValue("@PassengerUname", UserSession.PassengerUsername);

                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    sr.dataGridView1.DataSource = dt;
                    sr.Show();
                    MessageBox.Show(sr, "Your Ride has been Booked...");

                }
                else
                {
                    MessageBox.Show("Driver Id Not Matched.");
                }



            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Exception occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                this.Hide();
            }
        }

        private void did_TextChanged(object sender, EventArgs e)
        {


        }
        public string GenerateNumber()
        {
            Random r = new Random();
            int k = r.Next(1000, 9999);
            return k.ToString();
        }

        private void Ride_Details_Load(object sender, EventArgs e)
        {
            potp.Text = GenerateNumber();
            UserSession.otp = potp.Text;

        }

        private void payamount_TextChanged(object sender, EventArgs e)
        {
            payamount.Text = UserSession.Billamount;
        }
    }
}
