﻿using System;
using System.Windows.Forms;

public class Navigate
{
    
    public static void LoadForm(Panel mainpanel, object Form)
    {
        if (mainpanel.Controls.Count > 0)
            mainpanel.Controls.RemoveAt(0);
        Form f = Form as Form;
        f.TopLevel = false;
        f.Dock = DockStyle.Fill;
        mainpanel.Controls.Add(f);
        mainpanel.Tag = f;
        f.Show();
    }
}
