﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Bikxie.Properties
{
    public partial class passengerRegistration : Form
    {
        public passengerRegistration()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pback_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
        }

        private void pregister_Click(object sender, EventArgs e)
        {
            try
            {
                
                SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

                string q = "insert into passenger(PassengerName,PassengerAge,Gender,PassengerMobileNo,PassengerUname,PassengerPassword) values (@PassengerName,@PassengerAge,@Gender,@PassengerMobileNo,@PassengerUname,@PassengerPassword)";

                SqlCommand cmd = new SqlCommand(q, con);

                con.Open();

                cmd.Parameters.AddWithValue("@PassengerName", pname.Text);

                cmd.Parameters.AddWithValue("@PassengerAge", page.Text);

                if (pmale.Checked)
                {
                    cmd.Parameters.AddWithValue("@Gender", "Male");
                }
                else if (pfemale.Checked)
                {
                    cmd.Parameters.AddWithValue("@Gender", "Female");
                }
                cmd.Parameters.AddWithValue("@PassengerMobileNo", pmob.Text);

                cmd.Parameters.AddWithValue("@PassengerUname", puname.Text);

                cmd.Parameters.AddWithValue("@PassengerPassword", ppassword.Text);

                cmd.ExecuteNonQuery();

                con.Close();

            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Exception occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                MessageBox.Show("Process completed.");
            }
        }
    }
}
