﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Bikxie.Properties
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void DriverDB_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;

            string Query = "select DriverId,DriverName,DriverAge,Gender,DriverMobileNo,DriverLocation,licenseNumber,IsActive from driver";

            ShowDB(Query);

        }

        private void PassengerDB_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;

            string Query = "select PassengerId ,PassengerName ,PassengerAge,Gender,PassengerMobileNo from passenger";

            ShowDB(Query);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

            con.Open();

            string q = "UPDATE driver SET IsActive = 0 WHERE DriverId = @DriverId;";

            SqlCommand cmd = new SqlCommand(q, con);

            cmd.Parameters.AddWithValue("@DriverId", banid.Text);

            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Driver" + banid.Text + "Banned SuccessFully...");
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

            con.Open();

            string q = "UPDATE driver SET IsActive = 1 WHERE DriverId = @DriverId;";

            SqlCommand cmd = new SqlCommand(q, con);

            cmd.Parameters.AddWithValue("@DriverId", banid.Text);

            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Driver" + banid.Text + "Removed Ban SuccessFully...");
        }

        private void Ban_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;

            string Query = "select DriverId,DriverName,DriverAge,Gender,DriverMobileNo,DriverLocation,licenseNumber,IsActive from driver";

            ShowDB(Query);
        }
        public void ShowDB(string q)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

                SqlCommand cmd = new SqlCommand(q, con);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;

                }
                else
                {
                    MessageBox.Show("No data available.");
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Exception occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                MessageBox.Show("Data's Show Successfully");
            }
        }

        private void Rides_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

                string procedurename = "SP_HISTORY";
               
                SqlCommand cmd = new SqlCommand(procedurename, con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;

                }
                else
                {
                    MessageBox.Show("No data available.");
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Exception occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                MessageBox.Show("Data's Show Successfully");
            }
        }
    }
}
