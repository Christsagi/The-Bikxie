﻿using Microsoft.Data.SqlClient;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Bikxie.Properties
{
    public partial class Driver_update : Form
    {
        public Driver_update()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Collected_Click(object sender, EventArgs e)
        {
            if (amount.Text == "")
            {
                MessageBox.Show("Check your Kilometer or Update Your Kilometer.");
            }
            else
            {
                MessageBox.Show("Rides has Completed Succesfully..");

                this.Hide();

                start_ride_user_details st = new start_ride_user_details();
                st.Hide();

                Driver_main driver_Main = new Driver_main();
                driver_Main.Show();

                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

                    string q = " INSERT INTO Ridehistory (Date,DriverId,DriverName,PassengerId,PassengerName,FromPlace,ToPlace,Start_Time,End_Time,Bill,BillStatus) VALUES (@Date,@DriverId,@DriverName,@PassengerId,@PassengerName,@FromPlace,@ToPlace,@Start_Time,@End_Time,@Bill,@BillStatus) ";

                    SqlCommand cmd = new SqlCommand(q, con);//

                    con.Open();

                    cmd.Parameters.AddWithValue("@Date", UserSession.Date);

                    cmd.Parameters.AddWithValue("@DriverId", UserSession.Driverid);

                    cmd.Parameters.AddWithValue("@DriverName",UserSession.DriverUsername);
                    
                    cmd.Parameters.AddWithValue("@PassengerId", UserSession.Passengerid);

                    cmd.Parameters.AddWithValue("@PassengerName",UserSession.PassengerUsername);

                    cmd.Parameters.AddWithValue("@FromPlace", UserSession.Pickup);

                    cmd.Parameters.AddWithValue("@ToPlace", UserSession.Drop);

                    cmd.Parameters.AddWithValue("@Start_Time", UserSession.Starttime);

                    cmd.Parameters.AddWithValue("@End_Time", UserSession.Endtime);

                    cmd.Parameters.AddWithValue("@Bill", UserSession.Billamount);

                    cmd.Parameters.AddWithValue("@BillStatus", UserSession.BillStatus);

                    cmd.ExecuteNonQuery();

                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}");
                }

            }

        }

        private void amount_TextChanged(object sender, EventArgs e)
        {

        }

        private void otp_Check_Click(object sender, EventArgs e)
        {

            if (otp.Text == UserSession.otp)
            {
                MessageBox.Show("Otp has Matched Successfully..Enjoy your Ride");
            }
            else
            {
                MessageBox.Show("Invalid Otp.Your Otp and Passenger Otp are Not Matched!!");
            }
        }

        private void calculate_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value == 0)
            {
                MessageBox.Show("Enter Kilometer");
            }
            else
            {
                MessageBox.Show("Wait...Bill is Generate");

                UserSession.Kilometers = numericUpDown1.Value.ToString();

                int km = int.Parse(UserSession.Kilometers);

                int amt = km * 5;

                UserSession.Billamount = amt.ToString();

                amount.Text = UserSession.Billamount;
            }

        }

        private void update_Click(object sender, EventArgs e)
        {
            if (pickup.Checked == true && drop.Checked==false)
            {
                DateTime now = DateTime.Now;

                UserSession.Date = now.ToString("yyyy-MM-dd");

                UserSession.Starttime = now.ToString("HH:mm:ss");

                MessageBox.Show("Start Drive...Carefull Drive..");


            }
            else if(drop.Checked == true && pickup.Checked==false)
            {
                DateTime now = DateTime.Now;

                UserSession.Endtime = now.ToString("HH:mm:ss");

                MessageBox.Show("Thank You !Safety Is Our Important.");
            }
            else
            {
                MessageBox.Show("Select Any One Atpickup or AtDrop");
            }
        }
    }
}
