﻿namespace Bikxie.Properties
{
    partial class driverRegisteration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(driverRegisteration));
            label1 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            label4 = new Label();
            dname = new TextBox();
            label5 = new Label();
            dage = new TextBox();
            label6 = new Label();
            dmale = new RadioButton();
            dfemale = new RadioButton();
            label7 = new Label();
            dmob = new TextBox();
            label8 = new Label();
            location = new TextBox();
            label9 = new Label();
            license = new TextBox();
            label10 = new Label();
            duname = new TextBox();
            label11 = new Label();
            dpassword = new TextBox();
            register = new Button();
            back = new Button();
            label12 = new Label();
            plateno = new TextBox();
            label13 = new Label();
            vcolor = new TextBox();
            label14 = new Label();
            vmodel = new TextBox();
            label15 = new Label();
            vname = new TextBox();
            label16 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 25.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(32, 22);
            label1.Name = "label1";
            label1.Size = new Size(244, 51);
            label1.TabIndex = 0;
            label1.Text = "The Bikxie";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Book Antiqua", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(82, 88);
            label2.Name = "label2";
            label2.Size = new Size(280, 28);
            label2.TabIndex = 1;
            label2.Text = "Vehicles at your footsteps";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.BorderStyle = BorderStyle.Fixed3D;
            pictureBox1.Location = new Point(46, 167);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(316, 349);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 16.2F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(712, 22);
            label3.Name = "label3";
            label3.Size = new Size(114, 38);
            label3.TabIndex = 3;
            label3.Text = "Sign Up";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(732, 103);
            label4.Name = "label4";
            label4.Size = new Size(94, 33);
            label4.TabIndex = 4;
            label4.Text = "Name :";
            // 
            // dname
            // 
            dname.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dname.Location = new Point(927, 104);
            dname.Name = "dname";
            dname.Size = new Size(363, 30);
            dname.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(732, 200);
            label5.Name = "label5";
            label5.Size = new Size(74, 33);
            label5.TabIndex = 6;
            label5.Text = "Age :";
            // 
            // dage
            // 
            dage.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dage.Location = new Point(927, 204);
            dage.Name = "dage";
            dage.Size = new Size(363, 30);
            dage.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(732, 296);
            label6.Name = "label6";
            label6.Size = new Size(110, 33);
            label6.TabIndex = 8;
            label6.Text = "Gender :";
            // 
            // dmale
            // 
            dmale.AutoSize = true;
            dmale.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dmale.ForeColor = Color.White;
            dmale.Location = new Point(927, 299);
            dmale.Name = "dmale";
            dmale.Size = new Size(78, 30);
            dmale.TabIndex = 9;
            dmale.TabStop = true;
            dmale.Text = "Male";
            dmale.UseVisualStyleBackColor = true;
            // 
            // dfemale
            // 
            dfemale.AutoSize = true;
            dfemale.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dfemale.ForeColor = Color.White;
            dfemale.Location = new Point(1135, 299);
            dfemale.Name = "dfemale";
            dfemale.Size = new Size(100, 30);
            dfemale.TabIndex = 10;
            dfemale.TabStop = true;
            dfemale.Text = "Female";
            dfemale.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(732, 380);
            label7.Name = "label7";
            label7.Size = new Size(124, 33);
            label7.TabIndex = 11;
            label7.Text = "Mob.No :";
            // 
            // dmob
            // 
            dmob.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dmob.Location = new Point(927, 384);
            dmob.Name = "dmob";
            dmob.Size = new Size(363, 30);
            dmob.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(732, 486);
            label8.Name = "label8";
            label8.Size = new Size(128, 33);
            label8.TabIndex = 13;
            label8.Text = "Location :";
            // 
            // location
            // 
            location.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            location.Location = new Point(927, 486);
            location.Name = "location";
            location.Size = new Size(363, 30);
            location.TabIndex = 14;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(732, 578);
            label9.Name = "label9";
            label9.Size = new Size(156, 33);
            label9.TabIndex = 15;
            label9.Text = "License No :";
            // 
            // license
            // 
            license.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            license.Location = new Point(927, 578);
            license.Name = "license";
            license.Size = new Size(363, 30);
            license.TabIndex = 16;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(732, 669);
            label10.Name = "label10";
            label10.Size = new Size(152, 33);
            label10.TabIndex = 17;
            label10.Text = "User Name :";
            // 
            // duname
            // 
            duname.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            duname.Location = new Point(927, 669);
            duname.Name = "duname";
            duname.PlaceholderText = "Username and name Shoubld be same ";
            duname.Size = new Size(363, 30);
            duname.TabIndex = 18;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.White;
            label11.Location = new Point(732, 753);
            label11.Name = "label11";
            label11.Size = new Size(136, 33);
            label11.TabIndex = 19;
            label11.Text = "Password :";
            // 
            // dpassword
            // 
            dpassword.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dpassword.Location = new Point(927, 753);
            dpassword.Name = "dpassword";
            dpassword.Size = new Size(363, 30);
            dpassword.TabIndex = 20;
            // 
            // register
            // 
            register.BackColor = Color.LightSteelBlue;
            register.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            register.ForeColor = Color.Black;
            register.Image = Resources.Graphicloads_Folded_Check_contact_folded_48;
            register.ImageAlign = ContentAlignment.MiddleLeft;
            register.Location = new Point(1072, 884);
            register.Name = "register";
            register.Size = new Size(181, 55);
            register.TabIndex = 21;
            register.Text = "Register";
            register.TextAlign = ContentAlignment.MiddleRight;
            register.UseVisualStyleBackColor = false;
            register.Click += register_Click;
            // 
            // back
            // 
            back.BackColor = Color.LightSteelBlue;
            back.FlatAppearance.BorderSize = 2;
            back.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            back.Image = Resources.Custom_Icon_Design_Flatastic_1_Back_48;
            back.ImageAlign = ContentAlignment.MiddleLeft;
            back.Location = new Point(798, 884);
            back.Name = "back";
            back.Size = new Size(149, 55);
            back.TabIndex = 22;
            back.Text = "Back";
            back.TextAlign = ContentAlignment.MiddleRight;
            back.UseVisualStyleBackColor = false;
            back.Click += back_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Times New Roman", 16.2F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.White;
            label12.Location = new Point(73, 534);
            label12.Name = "label12";
            label12.Size = new Size(237, 33);
            label12.TabIndex = 23;
            label12.Text = "Fill Vechile Details ";
            // 
            // plateno
            // 
            plateno.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            plateno.Location = new Point(298, 873);
            plateno.Name = "plateno";
            plateno.Size = new Size(363, 30);
            plateno.TabIndex = 62;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.White;
            label13.Location = new Point(49, 873);
            label13.Name = "label13";
            label13.Size = new Size(127, 33);
            label13.TabIndex = 61;
            label13.Text = "Plate No :";
            // 
            // vcolor
            // 
            vcolor.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            vcolor.Location = new Point(298, 784);
            vcolor.Name = "vcolor";
            vcolor.Size = new Size(363, 30);
            vcolor.TabIndex = 60;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.White;
            label14.Location = new Point(68, 784);
            label14.Name = "label14";
            label14.Size = new Size(108, 33);
            label14.TabIndex = 59;
            label14.Text = "Colour :";
            // 
            // vmodel
            // 
            vmodel.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            vmodel.Location = new Point(298, 692);
            vmodel.Name = "vmodel";
            vmodel.Size = new Size(363, 30);
            vmodel.TabIndex = 58;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.White;
            label15.Location = new Point(73, 692);
            label15.Name = "label15";
            label15.Size = new Size(103, 33);
            label15.TabIndex = 57;
            label15.Text = "Model :";
            // 
            // vname
            // 
            vname.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            vname.Location = new Point(298, 604);
            vname.Name = "vname";
            vname.Size = new Size(363, 30);
            vname.TabIndex = 56;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Times New Roman", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.White;
            label16.Location = new Point(82, 604);
            label16.Name = "label16";
            label16.Size = new Size(94, 33);
            label16.TabIndex = 55;
            label16.Text = "Name :";
            // 
            // driverRegisteration
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(1336, 1055);
            Controls.Add(plateno);
            Controls.Add(label13);
            Controls.Add(vcolor);
            Controls.Add(label14);
            Controls.Add(vmodel);
            Controls.Add(label15);
            Controls.Add(vname);
            Controls.Add(label16);
            Controls.Add(label12);
            Controls.Add(back);
            Controls.Add(register);
            Controls.Add(dpassword);
            Controls.Add(label11);
            Controls.Add(duname);
            Controls.Add(label10);
            Controls.Add(license);
            Controls.Add(label9);
            Controls.Add(location);
            Controls.Add(label8);
            Controls.Add(dmob);
            Controls.Add(label7);
            Controls.Add(dfemale);
            Controls.Add(dmale);
            Controls.Add(label6);
            Controls.Add(dage);
            Controls.Add(label5);
            Controls.Add(dname);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "driverRegisteration";
            Text = "Driver Registration";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private PictureBox pictureBox1;
        private Label label3;
        private Label label4;
        private TextBox dname;
        private Label label5;
        private TextBox dage;
        private Label label6;
        private RadioButton dmale;
        private RadioButton dfemale;
        private Label label7;
        private TextBox dmob;
        private Label label8;
        private TextBox location;
        private Label label9;
        private TextBox license;
        private Label label10;
        private TextBox duname;
        private Label label11;
        private TextBox dpassword;
        private Button register;
        private Button back;
        private Label label12;
        private TextBox plateno;
        private Label label13;
        private TextBox vcolor;
        private Label label14;
        private TextBox vmodel;
        private Label label15;
        private TextBox vname;
        private Label label16;
    }
}