﻿
namespace Bikxie.Properties
{
    partial class Driver_update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Driver_update));
            label1 = new Label();
            label2 = new Label();
            otp = new TextBox();
            pickup = new CheckBox();
            drop = new CheckBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            calculate = new Button();
            update = new Button();
            label7 = new Label();
            label8 = new Label();
            Collected = new Button();
            amount = new TextBox();
            label9 = new Label();
            otp_Check = new Button();
            numericUpDown1 = new NumericUpDown();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(885, 22);
            label1.Name = "label1";
            label1.Size = new Size(179, 38);
            label1.TabIndex = 0;
            label1.Text = "Start Drives ";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(63, 123);
            label2.Name = "label2";
            label2.Size = new Size(62, 23);
            label2.TabIndex = 1;
            label2.Text = "OTP :";
            // 
            // otp
            // 
            otp.Anchor = AnchorStyles.None;
            otp.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            otp.Location = new Point(152, 121);
            otp.Name = "otp";
            otp.Size = new Size(125, 30);
            otp.TabIndex = 2;
            otp.TextChanged += textBox1_TextChanged;
            // 
            // pickup
            // 
            pickup.Anchor = AnchorStyles.None;
            pickup.AutoSize = true;
            pickup.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            pickup.ForeColor = Color.White;
            pickup.Location = new Point(63, 219);
            pickup.Name = "pickup";
            pickup.Size = new Size(127, 29);
            pickup.TabIndex = 3;
            pickup.Text = "AtPickup";
            pickup.UseVisualStyleBackColor = true;
            // 
            // drop
            // 
            drop.Anchor = AnchorStyles.None;
            drop.AutoSize = true;
            drop.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            drop.ForeColor = Color.White;
            drop.Location = new Point(300, 219);
            drop.Name = "drop";
            drop.Size = new Size(110, 29);
            drop.TabIndex = 4;
            drop.Text = "AtDrop";
            drop.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(759, 234);
            label3.Name = "label3";
            label3.Size = new Size(149, 25);
            label3.TabIndex = 5;
            label3.Text = "Calculate Bill ";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(651, 260);
            label4.Name = "label4";
            label4.Size = new Size(372, 26);
            label4.TabIndex = 6;
            label4.Text = "______________________________";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(658, 337);
            label5.Name = "label5";
            label5.Size = new Size(142, 26);
            label5.TabIndex = 7;
            label5.Text = "Kms Coverd :";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(912, 340);
            label6.Name = "label6";
            label6.Size = new Size(79, 26);
            label6.TabIndex = 9;
            label6.Text = "in Kms";
            // 
            // calculate
            // 
            calculate.Anchor = AnchorStyles.None;
            calculate.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            calculate.Image = Resources.Martz90_Circle_Calculator_48;
            calculate.ImageAlign = ContentAlignment.MiddleLeft;
            calculate.Location = new Point(776, 401);
            calculate.Name = "calculate";
            calculate.Size = new Size(164, 55);
            calculate.TabIndex = 10;
            calculate.Text = "Calculate";
            calculate.TextAlign = ContentAlignment.MiddleRight;
            calculate.UseVisualStyleBackColor = true;
            calculate.Click += calculate_Click;
            // 
            // update
            // 
            update.Anchor = AnchorStyles.None;
            update.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            update.Location = new Point(163, 284);
            update.Name = "update";
            update.Size = new Size(149, 36);
            update.TabIndex = 11;
            update.Text = "Update";
            update.UseVisualStyleBackColor = true;
            update.Click += update_Click;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(414, 488);
            label7.Name = "label7";
            label7.Size = new Size(108, 25);
            label7.TabIndex = 12;
            label7.Text = "The Bill is";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(288, 514);
            label8.Name = "label8";
            label8.Size = new Size(372, 26);
            label8.TabIndex = 13;
            label8.Text = "______________________________";
            label8.Click += label8_Click;
            // 
            // Collected
            // 
            Collected.Anchor = AnchorStyles.None;
            Collected.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Collected.Image = (Image)resources.GetObject("Collected.Image");
            Collected.ImageAlign = ContentAlignment.MiddleLeft;
            Collected.Location = new Point(615, 588);
            Collected.Name = "Collected";
            Collected.Size = new Size(162, 49);
            Collected.TabIndex = 14;
            Collected.Text = "Collected";
            Collected.TextAlign = ContentAlignment.MiddleRight;
            Collected.UseVisualStyleBackColor = true;
            Collected.Click += Collected_Click;
            // 
            // amount
            // 
            amount.Anchor = AnchorStyles.None;
            amount.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            amount.Location = new Point(378, 599);
            amount.Name = "amount";
            amount.Size = new Size(167, 30);
            amount.TabIndex = 15;
            amount.TextChanged += amount_TextChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.MidnightBlue;
            label9.Font = new Font("Times New Roman", 30F, FontStyle.Bold);
            label9.ForeColor = Color.White;
            label9.Location = new Point(12, 9);
            label9.Name = "label9";
            label9.Size = new Size(160, 57);
            label9.TabIndex = 19;
            label9.Text = "Bikxie";
            // 
            // otp_Check
            // 
            otp_Check.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            otp_Check.Location = new Point(327, 117);
            otp_Check.Name = "otp_Check";
            otp_Check.Size = new Size(142, 35);
            otp_Check.TabIndex = 20;
            otp_Check.Text = "Check";
            otp_Check.UseVisualStyleBackColor = true;
            otp_Check.Click += otp_Check_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(805, 340);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(106, 27);
            numericUpDown1.TabIndex = 21;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(1, 56);
            label10.Name = "label10";
            label10.Size = new Size(180, 26);
            label10.TabIndex = 22;
            label10.Text = "______________";
            // 
            // Driver_update
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(1076, 701);
            Controls.Add(label10);
            Controls.Add(numericUpDown1);
            Controls.Add(otp_Check);
            Controls.Add(label9);
            Controls.Add(amount);
            Controls.Add(Collected);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(update);
            Controls.Add(calculate);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(drop);
            Controls.Add(pickup);
            Controls.Add(otp);
            Controls.Add(label2);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Driver_update";
            Text = "Driver_update";
            Load += Driver_update_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void Driver_update_Load(object sender, EventArgs e)
        {
            
        }

        private void label7_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox otp;
        private CheckBox pickup;
        private CheckBox drop;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button calculate;
        private Button update;
        private Label label7;
        private Label label8;
        private Button Collected;
        private TextBox amount;
        private Label label9;
        private Button otp_Check;
        public NumericUpDown numericUpDown1;
        private Label label10;
    }
}