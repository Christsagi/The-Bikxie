﻿namespace Bikxie.Properties
{
    partial class start_ride_user_details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(start_ride_user_details));
            label1 = new Label();
            dataGridView1 = new DataGridView();
            label2 = new Label();
            label3 = new Label();
            pid = new TextBox();
            rideaccept = new Button();
            available = new CheckBox();
            notavailable = new CheckBox();
            riding = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(386, 20);
            label1.Name = "label1";
            label1.Size = new Size(319, 35);
            label1.TabIndex = 0;
            label1.Text = "Passenger Request Ride";
            label1.Click += label1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnKeystroke;
            dataGridView1.GridColor = Color.White;
            dataGridView1.ImeMode = ImeMode.NoControl;
            dataGridView1.Location = new Point(43, 74);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(971, 145);
            dataGridView1.TabIndex = 22;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(464, 376);
            label2.Name = "label2";
            label2.Size = new Size(140, 26);
            label2.TabIndex = 2;
            label2.Text = "Passenger id :";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.Flat;
            label3.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(340, 402);
            label3.Name = "label3";
            label3.Size = new Size(408, 26);
            label3.TabIndex = 3;
            label3.Text = "_________________________________";
            // 
            // pid
            // 
            pid.Anchor = AnchorStyles.None;
            pid.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            pid.Location = new Point(408, 500);
            pid.Name = "pid";
            pid.Size = new Size(231, 30);
            pid.TabIndex = 4;
            // 
            // rideaccept
            // 
            rideaccept.Anchor = AnchorStyles.None;
            rideaccept.BackColor = Color.MidnightBlue;
            rideaccept.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            rideaccept.ForeColor = Color.White;
            rideaccept.Image = (Image)resources.GetObject("rideaccept.Image");
            rideaccept.ImageAlign = ContentAlignment.MiddleLeft;
            rideaccept.Location = new Point(735, 486);
            rideaccept.Name = "rideaccept";
            rideaccept.Size = new Size(157, 50);
            rideaccept.TabIndex = 5;
            rideaccept.Text = "Accept";
            rideaccept.TextAlign = ContentAlignment.MiddleRight;
            rideaccept.UseVisualStyleBackColor = false;
            rideaccept.Click += rideaccept_Click;
            // 
            // available
            // 
            available.Anchor = AnchorStyles.None;
            available.AutoSize = true;
            available.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            available.ForeColor = Color.White;
            available.Location = new Point(123, 248);
            available.Name = "available";
            available.Size = new Size(174, 29);
            available.TabIndex = 6;
            available.Text = "Available Ride";
            available.UseVisualStyleBackColor = true;
            available.CheckedChanged += available_CheckedChanged;
            // 
            // notavailable
            // 
            notavailable.Anchor = AnchorStyles.None;
            notavailable.AutoSize = true;
            notavailable.BackColor = Color.Transparent;
            notavailable.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            notavailable.ForeColor = Color.White;
            notavailable.Location = new Point(464, 248);
            notavailable.Name = "notavailable";
            notavailable.Size = new Size(216, 29);
            notavailable.TabIndex = 7;
            notavailable.Text = "Not Available Ride";
            notavailable.UseVisualStyleBackColor = false;
            notavailable.CheckedChanged += notavailable_CheckedChanged;
            // 
            // riding
            // 
            riding.Anchor = AnchorStyles.None;
            riding.AutoSize = true;
            riding.BackColor = Color.Transparent;
            riding.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            riding.ForeColor = Color.White;
            riding.Location = new Point(861, 248);
            riding.Name = "riding";
            riding.Size = new Size(99, 29);
            riding.TabIndex = 8;
            riding.Text = "Riding";
            riding.UseVisualStyleBackColor = false;
            riding.CheckedChanged += riding_CheckedChanged;
            // 
            // start_ride_user_details
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1082, 638);
            Controls.Add(riding);
            Controls.Add(notavailable);
            Controls.Add(available);
            Controls.Add(rideaccept);
            Controls.Add(pid);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(dataGridView1);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "start_ride_user_details";
            Text = "start_ride_user_details";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox pid;
        private Button rideaccept;
        private CheckBox available;
        private CheckBox notavailable;
        private CheckBox riding;
        public DataGridView dataGridView1;
    }
}