﻿namespace Bikxie.Properties
{
    partial class Driver_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Driver_main));
            mainpanel = new Panel();
            panel1 = new Panel();
            label4 = new Label();
            checkride = new Button();
            logout = new Button();
            startdriving = new Button();
            label3 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // mainpanel
            // 
            mainpanel.Location = new Point(334, 0);
            mainpanel.Name = "mainpanel";
            mainpanel.Size = new Size(1002, 1031);
            mainpanel.TabIndex = 22;
            // 
            // panel1
            // 
            panel1.BackColor = Color.MidnightBlue;
            panel1.Controls.Add(label4);
            panel1.Controls.Add(checkride);
            panel1.Controls.Add(logout);
            panel1.Controls.Add(startdriving);
            panel1.Controls.Add(label3);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(334, 1031);
            panel1.TabIndex = 21;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.MidnightBlue;
            label4.Font = new Font("Times New Roman", 30F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(81, 39);
            label4.Name = "label4";
            label4.Size = new Size(160, 57);
            label4.TabIndex = 18;
            label4.Text = "Bikxie";
            // 
            // checkride
            // 
            checkride.BackColor = Color.MidnightBlue;
            checkride.BackgroundImageLayout = ImageLayout.None;
            checkride.FlatAppearance.BorderColor = Color.MidnightBlue;
            checkride.FlatAppearance.BorderSize = 0;
            checkride.FlatAppearance.MouseDownBackColor = Color.Black;
            checkride.FlatStyle = FlatStyle.Flat;
            checkride.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            checkride.ForeColor = Color.White;
            checkride.Image = Resources.Icojam_Blue_Bits_Database_check_64;
            checkride.ImageAlign = ContentAlignment.MiddleLeft;
            checkride.Location = new Point(49, 579);
            checkride.Name = "checkride";
            checkride.Size = new Size(249, 67);
            checkride.TabIndex = 15;
            checkride.Text = "Check Rides";
            checkride.TextAlign = ContentAlignment.MiddleRight;
            checkride.UseVisualStyleBackColor = false;
            checkride.Click += checkride_Click;
            // 
            // logout
            // 
            logout.BackColor = Color.MidnightBlue;
            logout.BackgroundImageLayout = ImageLayout.None;
            logout.FlatAppearance.BorderColor = Color.MidnightBlue;
            logout.FlatAppearance.BorderSize = 0;
            logout.FlatAppearance.MouseDownBackColor = Color.Black;
            logout.FlatStyle = FlatStyle.Flat;
            logout.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            logout.ForeColor = Color.White;
            logout.Image = Resources.Aha_Soft_Free_3d_Glossy_Interface_Run_64;
            logout.ImageAlign = ContentAlignment.MiddleLeft;
            logout.Location = new Point(81, 803);
            logout.Name = "logout";
            logout.Size = new Size(192, 83);
            logout.TabIndex = 16;
            logout.Text = "Log Out";
            logout.TextAlign = ContentAlignment.MiddleRight;
            logout.UseVisualStyleBackColor = false;
            logout.Click += logout_Click;
            // 
            // startdriving
            // 
            startdriving.BackColor = Color.MidnightBlue;
            startdriving.BackgroundImageLayout = ImageLayout.None;
            startdriving.FlatAppearance.BorderColor = Color.MidnightBlue;
            startdriving.FlatAppearance.BorderSize = 0;
            startdriving.FlatAppearance.MouseDownBackColor = Color.Black;
            startdriving.FlatStyle = FlatStyle.Flat;
            startdriving.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            startdriving.ForeColor = Color.White;
            startdriving.Image = Resources.Bike_Taxi_App_Bike_Taxi_Kolkata_Bike_Taxi_Number_Bike_Taxi_BroomBoom_1__1_;
            startdriving.ImageAlign = ContentAlignment.MiddleLeft;
            startdriving.Location = new Point(49, 371);
            startdriving.Name = "startdriving";
            startdriving.Size = new Size(249, 78);
            startdriving.TabIndex = 14;
            startdriving.Text = "Start Driving";
            startdriving.TextAlign = ContentAlignment.MiddleRight;
            startdriving.UseVisualStyleBackColor = false;
            startdriving.Click += startdriving_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.MidnightBlue;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(3, 96);
            label3.Name = "label3";
            label3.Size = new Size(310, 22);
            label3.TabIndex = 17;
            label3.Text = "______________________________";
            // 
            // Driver_main
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1336, 1031);
            Controls.Add(mainpanel);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Driver_main";
            Text = "Driver_main";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel mainpanel;
        private Panel panel1;
        private Label label4;
        private Button checkride;
        private Button logout;
        private Button startdriving;
        private Label label3;
    }
}