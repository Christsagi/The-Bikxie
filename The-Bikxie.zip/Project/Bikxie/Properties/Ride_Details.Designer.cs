﻿namespace Bikxie.Properties
{
    partial class Ride_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ride_Details));
            label9 = new Label();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            label2 = new Label();
            did = new TextBox();
            button1 = new Button();
            potp = new TextBox();
            label3 = new Label();
            label4 = new Label();
            payamount = new TextBox();
            Paid = new Button();
            label8 = new Label();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Times New Roman", 30F, FontStyle.Bold);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(1245, 5);
            label9.Name = "label9";
            label9.Size = new Size(160, 57);
            label9.TabIndex = 20;
            label9.Text = "Bikxie";
            label9.Click += label9_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Underline, GraphicsUnit.Point, 0);
            label1.Location = new Point(23, 46);
            label1.Name = "label1";
            label1.Size = new Size(196, 34);
            label1.TabIndex = 21;
            label1.Text = "Driver Details :";
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(23, 112);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1382, 220);
            dataGridView1.TabIndex = 22;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(69, 393);
            label2.Name = "label2";
            label2.Size = new Size(426, 26);
            label2.TabIndex = 23;
            label2.Text = "Which Driver do You want ? Enter driver id ";
            // 
            // did
            // 
            did.Anchor = AnchorStyles.None;
            did.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            did.Location = new Point(141, 465);
            did.Name = "did";
            did.Size = new Size(246, 30);
            did.TabIndex = 24;
            did.TextChanged += did_TextChanged;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.None;
            button1.BackColor = Color.MidnightBlue;
            button1.FlatAppearance.BorderSize = 2;
            button1.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Transparent;
            button1.Image = Resources.Graphicloads_Folded_Check_contact_folded_48;
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(119, 520);
            button1.Name = "button1";
            button1.Size = new Size(281, 78);
            button1.TabIndex = 25;
            button1.Text = "Confirm Driver";
            button1.TextAlign = ContentAlignment.MiddleRight;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // potp
            // 
            potp.Anchor = AnchorStyles.None;
            potp.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            potp.Location = new Point(1121, 416);
            potp.Name = "potp";
            potp.Size = new Size(125, 30);
            potp.TabIndex = 27;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(972, 416);
            label3.Name = "label3";
            label3.Size = new Size(61, 28);
            label3.TabIndex = 26;
            label3.Text = "OTP :";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(23, 419);
            label4.Name = "label4";
            label4.Size = new Size(528, 26);
            label4.TabIndex = 28;
            label4.Text = "___________________________________________";
            // 
            // payamount
            // 
            payamount.Anchor = AnchorStyles.None;
            payamount.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            payamount.ForeColor = Color.Black;
            payamount.Location = new Point(766, 670);
            payamount.Name = "payamount";
            payamount.Size = new Size(202, 30);
            payamount.TabIndex = 32;
            payamount.TextChanged += payamount_TextChanged;
            // 
            // Paid
            // 
            Paid.Anchor = AnchorStyles.None;
            Paid.BackColor = Color.MidnightBlue;
            Paid.Font = new Font("Times New Roman", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Paid.ForeColor = Color.Transparent;
            Paid.Image = Resources.paid;
            Paid.ImageAlign = ContentAlignment.MiddleLeft;
            Paid.Location = new Point(1030, 650);
            Paid.Name = "Paid";
            Paid.Size = new Size(179, 63);
            Paid.TabIndex = 31;
            Paid.Text = "Paid";
            Paid.TextAlign = ContentAlignment.MiddleRight;
            Paid.UseVisualStyleBackColor = false;
            Paid.Click += Paid_Click;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(676, 585);
            label8.Name = "label8";
            label8.Size = new Size(372, 26);
            label8.TabIndex = 30;
            label8.Text = "______________________________";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(802, 559);
            label7.Name = "label7";
            label7.Size = new Size(107, 26);
            label7.TabIndex = 29;
            label7.Text = "The Bill is";
            // 
            // Ride_Details
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1429, 928);
            Controls.Add(payamount);
            Controls.Add(Paid);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label4);
            Controls.Add(potp);
            Controls.Add(label3);
            Controls.Add(button1);
            Controls.Add(did);
            Controls.Add(label2);
            Controls.Add(dataGridView1);
            Controls.Add(label1);
            Controls.Add(label9);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Ride_Details";
            Text = "Ride_Details";
            Load += Ride_Details_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label9;
        private Label label1;
        private Label label2;
        private TextBox did;
        private Label label3;
        private Label label4;
        private TextBox payamount;
        private Button Paid;
        private Label label8;
        private Label label7;
        public DataGridView dataGridView1;
        public TextBox potp;
        private Button button1;
    }
}