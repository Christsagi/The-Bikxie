﻿namespace Bikxie.Properties
{
    partial class BookRIde
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookRIde));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            pickup = new ComboBox();
            drop = new ComboBox();
            Search = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            label1.Location = new Point(468, 35);
            label1.Name = "label1";
            label1.Size = new Size(360, 35);
            label1.TabIndex = 0;
            label1.Text = "Book And Enjoy Your Ride";
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.BorderStyle = BorderStyle.Fixed3D;
            pictureBox1.Location = new Point(29, 109);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(316, 349);
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(722, 199);
            label2.Name = "label2";
            label2.Size = new Size(264, 26);
            label2.TabIndex = 4;
            label2.Text = "Where do you want to go ?";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(392, 199);
            label3.Name = "label3";
            label3.Size = new Size(242, 26);
            label3.TabIndex = 5;
            label3.Text = "Select your Pickup Point";
            // 
            // pickup
            // 
            pickup.Anchor = AnchorStyles.None;
            pickup.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            pickup.FormattingEnabled = true;
            pickup.Items.AddRange(new object[] { "Adambakkam\t", "Adyar\t", "Alandur\t", "Alapakkam\t", "Alwarthirunagar\t", "Ambattur\t", "Aminjikarai\t", "Anna Nagar\t", "Annanur", "Arumbakkam\t", "Ashok Nagar\t", "Avadi\t", "Ayappakkam\t", "Basin Bridge\t", "Besant Nagar\t", "Chetpet\t", "Choolai\t", "MMDA Colony\t", "Defence Colony\t", "Egmore\t", "Ennore\t", "Ambattur\t", "George Town\t", "Gerugambakkam\t", "Gopalapuram\t", "Guindy\t", "Sikkarayapuram\t", "ICF Colony\t", "Injambakkam\t", "Irumbuliyur\t", "Iyyapanthangal\t", "Jamalia\t", "K.K.Nagar\t", "Kadaperi\t", "Kallikuppam\t", "Karambakkam\t", "Kathirvedu\t", "Kathivakkam\t", "Keelkattalai\t", "Kodungaiyur\t", "Kolappakkam\t", "Kolathur\t", "Korattur\t", "Korukkupet\t", "Kosapet\t", "Kottivakkam\t", "Kovilambakkam\t", "Kovur\t", "Kundrathur\t", "Lakshmipuram", "Little Mount\t", "M.G.R.Garden\t", "M.G.R.Nagar\t", "M.K.B.Nagar\t", "Madhavaram\t", "Madipakkam\t", "Maduravoyal\t", "Meenambakkam\t", "Manali\t", "manapakkam\t", "Mangadu\t", "Manjambakkam\t", "Mannadi\t", "Mathur MMDA\t", "Medavakkam\t", "Minjur\t", "Mogappair\t", "Moolakadai\t", "Mowlivakkam\t", "Mudichur\t", "Mugalivakkam\t", "Mylapore\t", "Nagalkeni\t", "Nandambakkam\t", "Nanganallur\t", "Naravarikuppam\t", "Neelankarai\t", "Nerkundrum\t", "Nesapakkam\t", "New Washermenpet\t", "Nolambur\t", "Old Washermenpet\t", "Oragadam\t", "Otteri\t", "Padi\t", "Palavakkam\t", "Pallavaram\t", "Pallikaranai\t", "Pammal\t", "Park Town\t", "Parrys Corner\t", "Pattabiram\t", "Pattalam\t", "Pattravakkam\t", "Pazhavanthangal\t", "Peerkankaranai\t", "Perambur\t", "Periamet\t", "Perungalathur\t", "Perungudi\t", "Ponniammanmedu\t", "Poonamallee\t", "Porur\t", "Pozhichalur\t", "Pudur\t", "Pulianthope\t", "Purasawalkam\t", "Puzhal\t", "Ramapuram\t", "Red Hills\t", "Royapuram\t", "Saidapet\t", "Saligramam\t", "Selaiyur\t", "Selavoyal\t", "Sembiam\t", "Sholinganallur\t", "Sowcarpet\t", "Surapet", "T.Nagar\t", "T.V.K.Nagar\t", "Tambaram\t", "Taramani\t", "Teynampet\t", "Thirumangalam\t", "Thirumazhisai\t", "Thirumullaivayal\t", "Thiruvanmiyur\t", "Thiruverkadu\t", "Thoraipakkam\t", "Thousand Lights", "Tiruvottiyur\t", "Tondiarpet\t", "Triplicane\t", "Trisulam ", "Vadapalani\t", "Valasaravakkam\t", "Vallalar Nagar\t", "Vandalur\t", "Varadharajapuram\t", "Velachery\t", "Vepery\t", "Villivakkam\t", "Virugambakkam\t", "Vyasarpadi\t", "West Mambalam\t", "Kancheepuram\t", "Chengalpattu\t", "Pazhaverkadu\t", "Ponneri", "Athipattu\t", "Red Hills\t", "Ennore\t", "Tiruvallur\t", "Arakkonam\t", "Sriperumbudur\t", "Tamaraipakkam\t", "Irungatukottai\t", "Kadambathur\t", "Chembarambakkam\t", "Singaperumalkoil\t", "Maraimalai nagar\t", "Urapakkam\t", "Guduvanchery\t", "Karapakkam\t             ", "Kanathur\t", "Muthukadu\t", "Kelambakkam\t", "Kovalam\t", "Siruseri" });
            pickup.Location = new Point(392, 259);
            pickup.Name = "pickup";
            pickup.Size = new Size(227, 30);
            pickup.TabIndex = 6;
            // 
            // drop
            // 
            drop.Anchor = AnchorStyles.None;
            drop.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            drop.FormattingEnabled = true;
            drop.Items.AddRange(new object[] { "Adambakkam\t", "Adyar\t", "Alandur\t", "Alapakkam\t", "Alwarthirunagar\t", "Ambattur\t", "Aminjikarai\t", "Anna Nagar\t", "Annanur", "Arumbakkam\t", "Ashok Nagar\t", "Avadi\t", "Ayappakkam\t", "Basin Bridge\t", "Besant Nagar\t", "Chetpet\t", "Choolai\t", "MMDA Colony\t", "Defence Colony\t", "Egmore\t", "Ennore\t", "Ambattur\t", "George Town\t", "Gerugambakkam\t", "Gopalapuram\t", "Guindy\t", "Sikkarayapuram\t", "ICF Colony\t", "Injambakkam\t", "Irumbuliyur\t", "Iyyapanthangal\t", "Jamalia\t", "K.K.Nagar\t", "Kadaperi\t", "Kallikuppam\t", "Karambakkam\t", "Kathirvedu\t", "Kathivakkam\t", "Keelkattalai\t", "Kodungaiyur\t", "Kolappakkam\t", "Kolathur\t", "Korattur\t", "Korukkupet\t", "Kosapet\t", "Kottivakkam\t", "Kovilambakkam\t", "Kovur\t", "Kundrathur\t", "Lakshmipuram", "Little Mount\t", "M.G.R.Garden\t", "M.G.R.Nagar\t", "M.K.B.Nagar\t", "Madhavaram\t", "Madipakkam\t", "Maduravoyal\t", "Meenambakkam\t", "Manali\t", "manapakkam\t", "Mangadu\t", "Manjambakkam\t", "Mannadi\t", "Mathur MMDA\t", "Medavakkam\t", "Minjur\t", "Mogappair\t", "Moolakadai\t", "Mowlivakkam\t", "Mudichur\t", "Mugalivakkam\t", "Mylapore\t", "Nagalkeni\t", "Nandambakkam\t", "Nanganallur\t", "Naravarikuppam\t", "Neelankarai\t", "Nerkundrum\t", "Nesapakkam\t", "New Washermenpet\t", "Nolambur\t", "Old Washermenpet\t", "Oragadam\t", "Otteri\t", "Padi\t", "Palavakkam\t", "Pallavaram\t", "Pallikaranai\t", "Pammal\t", "Park Town\t", "Parrys Corner\t", "Pattabiram\t", "Pattalam\t", "Pattravakkam\t", "Pazhavanthangal\t", "Peerkankaranai\t", "Perambur\t", "Periamet\t", "Perungalathur\t", "Perungudi\t", "Ponniammanmedu\t", "Poonamallee\t", "Porur\t", "Pozhichalur\t", "Pudur\t", "Pulianthope\t", "Purasawalkam\t", "Puzhal\t", "Ramapuram\t", "Red Hills\t", "Royapuram\t", "Saidapet\t", "Saligramam\t", "Selaiyur\t", "Selavoyal\t", "Sembiam\t", "Sholinganallur\t", "Sowcarpet\t", "Surapet", "T.Nagar\t", "T.V.K.Nagar\t", "Tambaram\t", "Taramani\t", "Teynampet\t", "Thirumangalam\t", "Thirumazhisai\t", "Thirumullaivayal\t", "Thiruvanmiyur\t", "Thiruverkadu\t", "Thoraipakkam\t", "Thousand Lights", "Tiruvottiyur\t", "Tondiarpet\t", "Triplicane\t", "Trisulam ", "Vadapalani\t", "Valasaravakkam\t", "Vallalar Nagar\t", "Vandalur\t", "Varadharajapuram\t", "Velachery\t", "Vepery\t", "Villivakkam\t", "Virugambakkam\t", "Vyasarpadi\t", "West Mambalam\t", "Kancheepuram\t", "Chengalpattu\t", "Pazhaverkadu\t", "Ponneri", "Athipattu\t", "Red Hills\t", "Ennore\t", "Tiruvallur\t", "Arakkonam\t", "Sriperumbudur\t", "Tamaraipakkam\t", "Irungatukottai\t", "Kadambathur\t", "Chembarambakkam\t", "Singaperumalkoil\t", "Maraimalai nagar\t", "Urapakkam\t", "Guduvanchery\t", "Karapakkam\t             ", "Kanathur\t", "Muthukadu\t", "Kelambakkam\t", "Kovalam\t", "Siruseri" });
            drop.Location = new Point(740, 259);
            drop.Name = "drop";
            drop.Size = new Size(227, 30);
            drop.TabIndex = 7;
            // 
            // Search
            // 
            Search.Anchor = AnchorStyles.None;
            Search.BackColor = Color.MidnightBlue;
            Search.BackgroundImageLayout = ImageLayout.Zoom;
            Search.Font = new Font("Times New Roman", 16F, FontStyle.Bold);
            Search.ForeColor = Color.Transparent;
            Search.Image = Resources.Custom_Icon_Design_Flatastic_4_Male_user_search_48;
            Search.ImageAlign = ContentAlignment.MiddleLeft;
            Search.Location = new Point(552, 348);
            Search.Name = "Search";
            Search.Size = new Size(159, 67);
            Search.TabIndex = 9;
            Search.Text = "Search";
            Search.TextAlign = ContentAlignment.MiddleRight;
            Search.UseVisualStyleBackColor = false;
            Search.Click += Search_Click;
            // 
            // BookRIde
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1082, 528);
            Controls.Add(Search);
            Controls.Add(drop);
            Controls.Add(pickup);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "BookRIde";
            Text = "BookRIde";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label3;
        private ComboBox pickup;
        private ComboBox drop;
        private Button Search;
    }
}