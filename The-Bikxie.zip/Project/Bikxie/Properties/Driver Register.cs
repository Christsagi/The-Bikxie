﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bikxie.Properties
{
    public partial class driverRegisteration : Form
    {
        public driverRegisteration()
        {
            InitializeComponent();
        }

        private void back_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
        }

        private void register_Click(object sender, EventArgs e)
        {

            try
            {
                if (dname.Text != "" && dage.Text != "" && (dmale.Checked == true && dfemale.Checked == false || dfemale.Checked == true && dmale.Checked == false) && dmob.Text != "" && location.Text != "" && license.Text != "" && duname.Text != "" && dpassword.Text != "" && vname.Text != "" && vmodel.Text != "" && vcolor.Text != "" && plateno.Text != "")
                {
                    SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=true");

                    string q = "insert into driver(DriverName,DriverAge,Gender,DriverMobileNo,DriverLocation,licenseNumber,DriverUname,DriverPassword,VechileName,VechileModel,VechileColor,VechilePlateNo) values (@DriverName,@DriverAge,@Gender,@DriverMobileNo,@DriverLocation,@licenseNumber,@DriverUname,@DriverPassword,@VechileName,@VechileModel,@VechileColor,@VechilePlateNo)";

                    SqlCommand cmd = new SqlCommand(q, con);

                    con.Open();

                    cmd.Parameters.AddWithValue("@DriverName", dname.Text);

                    cmd.Parameters.AddWithValue("@DriverAge", dage.Text);

                    if (dmale.Checked)
                    {
                        cmd.Parameters.AddWithValue("@Gender", "Male");
                    }
                    else if (dfemale.Checked)
                    {
                        cmd.Parameters.AddWithValue("@Gender", "Female");
                    }
                    cmd.Parameters.AddWithValue("@DriverMobileNo", dmob.Text);

                    cmd.Parameters.AddWithValue("@DriverLocation", location.Text);

                    cmd.Parameters.AddWithValue("@licenseNumber", license.Text);

                    cmd.Parameters.AddWithValue("@DriverUname", duname.Text);

                    cmd.Parameters.AddWithValue("@DriverPassword", dpassword.Text);

                    cmd.Parameters.AddWithValue("@VechileName", vname.Text);

                    cmd.Parameters.AddWithValue("@VechileModel", vmodel.Text);

                    cmd.Parameters.AddWithValue("@VechileColor", vcolor.Text);

                    cmd.Parameters.AddWithValue("@VechilePlateNo", plateno.Text);

                    cmd.ExecuteNonQuery();

                    con.Close();

                }
                else
                {
                    MessageBox.Show("All Fields Are Mandatory.Fill All Fields...");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Exception occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                MessageBox.Show("Process completed.");
            }

        }
                
       

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
