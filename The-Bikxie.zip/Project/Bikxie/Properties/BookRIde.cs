﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bikxie.Properties
{
    public partial class BookRIde : Form
    {
        public BookRIde()
        {
            InitializeComponent();
        }

        private void Search_Click(object sender, EventArgs e)
        {
            try
            {

                if(pickup.Text == "" || drop.Text == "")
                {
                    MessageBox.Show("Please Enter Pick up & Drop location");
                    return;
                }
                UserSession.Pickup=pickup.Text;

                UserSession.Drop = drop.Text;

                this.Hide();

                Ride_Details ride_Details = new Ride_Details();
               

                SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bikxie;Integrated Security=false");

                string q = "select DriverId,DriverName,DriverMobileNo,VechileName,VechileColor,VechilePlateNo from driver where DriverLocation = @DriverLocation and Status='Available'";

                SqlCommand cmd = new SqlCommand(q, con);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                cmd.Parameters.AddWithValue("@DriverLocation", pickup.Text.Trim());

                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    ride_Details.dataGridView1.DataSource = dt;

                    ride_Details.Show();

                    MessageBox.Show(ride_Details,"Driver Details Showing...Please select any one driver.");

                }
                else
                {
                    MessageBox.Show("No Driver available At Your Location.");
                }

               

            }
            catch (SqlException ex)
            {
                MessageBox.Show("SQL Exception occurred: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                this.Close();
            }
           

        }
    }
}
