﻿namespace Bikxie
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            label1 = new Label();
            label2 = new Label();
            signup = new Button();
            label3 = new Label();
            mode = new ComboBox();
            label4 = new Label();
            label5 = new Label();
            uname = new TextBox();
            label6 = new Label();
            label7 = new Label();
            password = new TextBox();
            signin = new Button();
            showpass = new CheckBox();
            SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(label1, "label1");
            label1.BackColor = Color.Transparent;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(label2, "label2");
            label2.BackColor = Color.Transparent;
            label2.ForeColor = Color.Black;
            label2.Name = "label2";
            // 
            // signup
            // 
            signup.BackColor = Color.MidnightBlue;
            signup.FlatAppearance.BorderColor = Color.White;
            signup.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(signup, "signup");
            signup.ForeColor = Color.Transparent;
            signup.Name = "signup";
            signup.UseVisualStyleBackColor = false;
            signup.Click += signup_Click;
            // 
            // label3
            // 
            resources.ApplyResources(label3, "label3");
            label3.BackColor = Color.Transparent;
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Name = "label3";
            // 
            // mode
            // 
            mode.BackColor = Color.MistyRose;
            resources.ApplyResources(mode, "mode");
            mode.FormattingEnabled = true;
            mode.Items.AddRange(new object[] { resources.GetString("mode.Items"), resources.GetString("mode.Items1"), resources.GetString("mode.Items2") });
            mode.Name = "mode";
            // 
            // label4
            // 
            resources.ApplyResources(label4, "label4");
            label4.BackColor = Color.Transparent;
            label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(label5, "label5");
            label5.BackColor = Color.Transparent;
            label5.Name = "label5";
            // 
            // uname
            // 
            uname.BackColor = SystemColors.Info;
            resources.ApplyResources(uname, "uname");
            uname.Name = "uname";
            // 
            // label6
            // 
            resources.ApplyResources(label6, "label6");
            label6.BackColor = Color.Transparent;
            label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(label7, "label7");
            label7.BackColor = Color.Transparent;
            label7.Name = "label7";
            // 
            // password
            // 
            password.BackColor = SystemColors.Info;
            resources.ApplyResources(password, "password");
            password.Name = "password";
            password.UseSystemPasswordChar = true;
            // 
            // signin
            // 
            signin.BackColor = Color.MidnightBlue;
            signin.FlatAppearance.BorderColor = Color.White;
            signin.FlatAppearance.BorderSize = 2;
            resources.ApplyResources(signin, "signin");
            signin.ForeColor = Color.Transparent;
            signin.Name = "signin";
            signin.UseVisualStyleBackColor = false;
            signin.Click += signin_Click;
            // 
            // showpass
            // 
            resources.ApplyResources(showpass, "showpass");
            showpass.BackColor = Color.Transparent;
            showpass.Name = "showpass";
            showpass.UseVisualStyleBackColor = false;
            showpass.CheckedChanged += showpass_CheckedChanged;
            // 
            // Login
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(showpass);
            Controls.Add(signin);
            Controls.Add(password);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(uname);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(mode);
            Controls.Add(label3);
            Controls.Add(signup);
            Controls.Add(label2);
            Controls.Add(label1);
            DoubleBuffered = true;
            Name = "Login";
            Load += Login_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button signup;
        private Label label3;
        private ComboBox mode;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox password;
        private Button signin;
        private CheckBox showpass;
        public TextBox uname;
    }
}
