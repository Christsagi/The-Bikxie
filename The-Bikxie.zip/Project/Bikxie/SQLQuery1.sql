create database Bikxie

use Bikxie          

create table driver(
DriverId int primary key identity(1001,1),
DriverName varchar(30) not null,
DriverAge int not null check(DriverAge>18),            
Gender varchar(10) not null,
DriverMobileNo Bigint unique,
DriverLocation varchar(40) not null,
licenseNumber varchar(30) unique,
DriverUname varchar(25) unique,
DriverPassword varchar(30) not null,
VechileName varchar(30) not null,
VechileModel int not null,
VechileColor varchar(20) not null,
VechilePlateNo varchar(20) not null,
IsActive bit default 1,
Status varchar(20) default null);

create table passenger(
PassengerId int primary key identity(101,1),
PassengerName varchar(30) not null,
PassengerAge int not null,
Gender varchar(10) not null,
PassengerMobileNo Bigint unique,
PassengerUname varchar(25) unique,
PassengerPassword varchar(30) not null);

create table Ridehistory(
Date date,
DriverId int foreign key references driver(DriverId),
DriverName varchar(30) not null,
PassengerId int foreign key references passenger(PassengerId),
PassengerName varchar(30) not null,
FromPlace varchar(30) not null,
ToPlace varchar(30) not null,
Start_Time time not null,
End_Time time not null ,
Bill int not null,
BillStatus varchar(20) not null)


exec SP_HISTORY

select * from driver

select * from passenger

select * from sys.tables

--procedure--
--CREATE PROC SP_HISTORY
--AS
--BEGIN
--	select * from Ridehistory
--END */